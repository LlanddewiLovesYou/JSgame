------------------------------------------
Final Fantasy Font version 0.5
By Juan Pablo Reyes Altamirano
Copyright 1999 Juan Pablo Reyes Altamirano
------------------------------------------

This brand new revamped version of the
Final Fantasy Font now has the whole
english alphabet in Capital Letters (I
wouldn't know where to start on the lower
case letters). Some lower case letters are
referred to the sub font of the Squaresoft
logo.

All Following letters exist in this font
A, B, C, D, E, F, G, H, I, J, K, L, M, N
O, P, Q, R, S, T, U, V, W, X, Y, Z

The following are lower cased letters that
exist but are in Square logo type.
a, e, f, o, q, r, s, t, u

Enjoy

-Dream Master
